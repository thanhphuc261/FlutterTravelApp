const componentStyles = () => ({
  tabCircle: {
    lineHeight: "60px",
    width: "60px",
    height: "60px",
    padding: 0,
    textAlign: "center",
    borderRadius: "50%",
    flex: "unset",
    minWidth: "unset!important",
  },
});

export default componentStyles;
